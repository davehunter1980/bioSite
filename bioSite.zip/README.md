# bioSite
 Bio Site for web development project

<h1>CSD 340 Web Development with HTML and CSS</h1>

<h2>Contributors</h2>
<ul>
    <li>Dave Hunter</li>
    <li>Darren Darren Osier</li>
</ul>